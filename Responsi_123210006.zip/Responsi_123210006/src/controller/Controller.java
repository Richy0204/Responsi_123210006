/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;
import view.*;
import model.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author PC PRAKTIKUM
 */
public class Controller {
    Model model;
    View view;
    
    private String data[][];
    private String marker;
    
    public Controller (Model model, View view){
        this.model = model;
        this.view = view;
        data = model.readTable();
        
        view.table.setModel(new DefaultTableModel(data, new String[]{
            "Judul", "Alur", "Orisinalitas", "Pemilihan_Kata", "Nilai"
        }) {
            boolean[] canEdit = new boolean[]{
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit[columnIndex];
            }
        });
        view.table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int row = view.table.getSelectedRow();
                String judul = view.table.getValueAt(row, 0).toString();
                String alur = view.table.getValueAt(row, 1).toString();
                String orisinalitas = view.table.getValueAt(row, 2).toString();
                String pemilihanKata = view.table.getValueAt(row, 3).toString();
               
                
                view.setJudul(judul);
                view.setAlur(alur);
                view.setOrisinalitas(orisinalitas);
                view.setPemilihanKata(pemilihanKata);
                
             }
        });
        
        view.input.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
               String judul = view.getJudul();
               double alur = Double.parseDouble(view.getAlur() );
               double orisinalitas = Double.parseDouble(view.getOrisinalitas() );
               double pemilihanKata = Double.parseDouble(view.getPemilihanKata());
                             
               double nilai = (alur+orisinalitas+pemilihanKata)/3;
                
               
                    model.insertData(judul, alur, orisinalitas, pemilihanKata, nilai);
                
                    marker = "";
                    
                    data = model.readTable();
                    view.table.setModel(new DefaultTableModel(data, new String[]{
                       "Judul", "Alur", "Orisinalitas", "Pemilihakata", "Nilai"
                    }) {
                        boolean[] canEdit = new boolean[]{
                            false, false, false, false
                        };

                        public boolean isCellEditable(int rowIndex, int columnIndex) {
                            return canEdit[columnIndex];
                        }
                    });
                    
                }        
        });
        
        
       
    }
    
}



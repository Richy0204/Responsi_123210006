/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

/**
 *
 * @author PC PRAKTIKUM
 */
public class Model extends Konektor{
    public Model(){
        
    }
    
    public int readDataLomba(){
        try{
            int totalData = 0;
            String query = " SELECT * FROM  `lomba`";
            statement = koneksi.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            
            while (resultSet.next()){
                totalData++;
            }
            statement.close();
            return totalData;   
            
        }catch (Exception e){
            System.out.println("Eror : " + e.getMessage());
            return 0; 
        }
    }
    
   public String[][] readTable() {

        String data[][] = new String[readDataLomba()][5];
        try {
            int indexData = 0;
            String query = "SELECT * FROM `lomba`";
            statement = koneksi.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                data[indexData][0] = resultSet.getString("judul");
                data[indexData][1] = resultSet.getString("alur");
                data[indexData][2] = resultSet.getString("orisinalitas");
                data[indexData][3] = resultSet.getString("pemilihanKata");
                data[indexData][4] = resultSet.getString("nilai");
                indexData++;
            }
            statement.close();
            return data;
        } catch (Exception e) {
            System.out.println("Error : " + e.getMessage());
            return data;
        }
   }
   
  public void insertData(String judul, double alur, double orisinalitas, double pemilihanKata, double nilai ) {
        
        try {
            String query = "INSERT INTO `lomba` (`judul`, `alur`, `orisinalitas`, `pemilihanKata`, `nilai`) "
                    + "VALUES "
                    + "('" + judul + "','" + alur + "','" + orisinalitas + "','" + pemilihanKata + "','" + nilai + "')";

            statement = koneksi.createStatement();
            statement.executeUpdate(query);

            statement.close();
            JOptionPane.showMessageDialog(null, "DataJudul Berhasil Ditambahkan");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Salah Inputan, Min = 0!");
        }
    }
   
   
}
    